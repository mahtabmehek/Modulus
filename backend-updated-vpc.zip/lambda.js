const serverless = require('serverless-http');
const app = require('./server');

// Create the Lambda handler with proper API Gateway proxy integration
const handler = serverless(app, {
  // Strip the /prod stage from the path since Express routes expect /api/*
  stripBasePath: '/prod',
  // Enable request logging for debugging
  binary: false,
  request: (request, event, context) => {
    console.log('🔍 Lambda Request Debug:');
    console.log('Event path:', event.path);
    console.log('Event pathParameters:', event.pathParameters);
    console.log('Event requestContext.path:', event.requestContext?.path);
    console.log('Event httpMethod:', event.httpMethod);
    console.log('Request URL will be:', request.url);
  }
});

module.exports = { handler };
