﻿const serverless = require('serverless-http');

console.log('Lambda starting...');

let app;
try {
  app = require('./server');
  console.log('Server loaded successfully');
} catch (error) {
  console.error('Error loading server:', error);
  // Fallback simple app
  const express = require('express');
  app = express();
  app.use(express.json());
  app.get('/api/health', (req, res) => {
    res.json({ status: 'Error', message: 'Server failed to load', error: error.message });
  });
}

const handler = serverless(app);

exports.handler = async (event, context) => {
  console.log('Lambda Event received');
  
  try {
    const result = await handler(event, context);
    return result;
  } catch (error) {
    console.error('Lambda Handler Error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        error: 'Internal Server Error',
        message: error.message
      })
    };
  }
};
