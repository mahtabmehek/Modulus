const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();

// Admin endpoint to create test users
// This should only be used in development/testing
router.post('/create-test-users', async (req, res) => {
  try {
    // Check if we're in production and have the right access code
    const { accessCode } = req.body;
    if (accessCode !== 'mahtabmehek1337') {
      return res.status(403).json({ error: 'Invalid access code' });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({ error: 'Database connection not available' });
    }

    // Password for all test users
    const password = 'Mahtabmehek@1337';
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // Test users to create
    const testUsers = [
      { email: 'student@test.com', name: 'Test Student', role: 'student', level: 1, level_name: 'Beginner', total_points: 0 },
      { email: 'instructor@test.com', name: 'Test Instructor', role: 'instructor', level: 5, level_name: 'Advanced', total_points: 500 },
      { email: 'admin@test.com', name: 'Test Admin', role: 'admin', level: 10, level_name: 'Expert', total_points: 1000 },
      { email: 'student@modulus.com', name: 'Modulus Student', role: 'student', level: 1, level_name: 'Beginner', total_points: 0 },
      { email: 'instructor@modulus.com', name: 'Modulus Instructor', role: 'instructor', level: 5, level_name: 'Advanced', total_points: 500 },
      { email: 'admin@modulus.com', name: 'Modulus Admin', role: 'admin', level: 10, level_name: 'Expert', total_points: 1000 }
    ];

    // First, delete existing test users
    const deleteQuery = `
      DELETE FROM users 
      WHERE email IN ('student@test.com', 'instructor@test.com', 'admin@test.com', 
                      'student@modulus.com', 'instructor@modulus.com', 'admin@modulus.com')
    `;
    await pool.query(deleteQuery);

    // Insert new test users
    const insertQuery = `
      INSERT INTO users (email, password_hash, name, role, is_approved, created_at, last_active, level, level_name, total_points)
      VALUES ($1, $2, $3, $4, true, NOW(), NOW(), $5, $6, $7)
    `;

    const results = [];
    for (const user of testUsers) {
      try {
        const result = await pool.query(insertQuery, [
          user.email,
          passwordHash,
          user.name,
          user.role,
          user.level,
          user.level_name,
          user.total_points
        ]);
        results.push({ email: user.email, status: 'created' });
      } catch (error) {
        results.push({ email: user.email, status: 'error', error: error.message });
      }
    }

    // Verify the users were created
    const verifyQuery = `
      SELECT id, email, name, role, is_approved, created_at 
      FROM users 
      WHERE email LIKE '%@test.com' OR email LIKE '%@modulus.com' 
      ORDER BY role, email
    `;
    const verifyResult = await pool.query(verifyQuery);

    res.json({
      message: 'Test users creation completed',
      password: password,
      results: results,
      created_users: verifyResult.rows,
      total_created: verifyResult.rows.length
    });

  } catch (error) {
    console.error('Error creating test users:', error);
    res.status(500).json({ 
      error: 'Failed to create test users', 
      details: error.message 
    });
  }
});

// Admin endpoint to verify test users
router.get('/test-users', async (req, res) => {
  try {
    const pool = req.app.locals.pool;
    if (!pool) {
      return res.status(500).json({ error: 'Database connection not available' });
    }

    const query = `
      SELECT id, email, name, role, is_approved, created_at, last_active, level, total_points
      FROM users 
      WHERE email LIKE '%@test.com' OR email LIKE '%@modulus.com' 
      ORDER BY role, email
    `;
    const result = await pool.query(query);

    res.json({
      message: 'Test users found',
      users: result.rows,
      total: result.rows.length,
      password_hint: 'Mahtabmehek@1337'
    });

  } catch (error) {
    console.error('Error fetching test users:', error);
    res.status(500).json({ 
      error: 'Failed to fetch test users', 
      details: error.message 
    });
  }
});

// Simple seed endpoint for easier access
router.get('/seed', async (req, res) => {
  try {
    const pool = req.app.locals.db;
    if (!pool) {
      return res.status(500).json({ error: 'Database connection not available' });
    }

    // Password for all test users
    const password = 'Mahtabmehek@1337';
    const saltRounds = 12;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    // Test users to create
    const testUsers = [
      { email: 'student@test.com', name: 'Test Student', role: 'student', level: 1, level_name: 'Beginner', total_points: 0 },
      { email: 'instructor@test.com', name: 'Test Instructor', role: 'instructor', level: 5, level_name: 'Advanced', total_points: 500 },
      { email: 'admin@test.com', name: 'Test Admin', role: 'admin', level: 10, level_name: 'Expert', total_points: 1000 },
      { email: 'student', name: 'Simple Student', role: 'student', level: 1, level_name: 'Beginner', total_points: 0 },
      { email: 'instructor', name: 'Simple Instructor', role: 'instructor', level: 5, level_name: 'Advanced', total_points: 500 },
      { email: 'admin', name: 'Simple Admin', role: 'admin', level: 10, level_name: 'Expert', total_points: 1000 }
    ];

    // Create users table if it doesn't exist
    const createTableQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL CHECK (role IN ('student', 'instructor', 'admin')),
        is_approved BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        level INTEGER DEFAULT 1,
        level_name VARCHAR(50) DEFAULT 'Beginner',
        total_points INTEGER DEFAULT 0
      );
    `;
    
    await pool.query(createTableQuery);

    // Insert test users
    const insertQuery = `
      INSERT INTO users (email, name, password_hash, role, is_approved, level, level_name, total_points)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      ON CONFLICT (email) DO UPDATE SET
        password_hash = $3,
        role = $4,
        is_approved = $5,
        level = $6,
        level_name = $7,
        total_points = $8
      RETURNING id, email, name, role;
    `;

    const insertedUsers = [];
    for (const user of testUsers) {
      const result = await pool.query(insertQuery, [
        user.email,
        user.name,
        passwordHash,
        user.role,
        true,
        user.level,
        user.level_name,
        user.total_points
      ]);
      insertedUsers.push(result.rows[0]);
    }

    res.json({
      message: 'Test users seeded successfully',
      users: insertedUsers,
      total: insertedUsers.length,
      password: password
    });

  } catch (error) {
    console.error('Error seeding test users:', error);
    res.status(500).json({ 
      error: 'Failed to seed test users', 
      details: error.message 
    });
  }
});

// Admin endpoint to create basic database tables
router.post('/init-database', async (req, res) => {
  try {
    // Check if we have the right access code
    const { accessCode } = req.body;
    if (accessCode !== 'mahtabmehek1337') {
      return res.status(403).json({ error: 'Invalid access code' });
    }

    const pool = req.app.locals.db;
    if (!pool) {
      return res.status(500).json({ error: 'Database connection not available' });
    }

    // Create users table - simplified version first
    const createUsersQuery = `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'instructor', 'staff', 'admin')),
        is_approved BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `;
    
    await pool.query(createUsersQuery);

    // Add missing columns if they don't exist
    const alterQueries = [
      'ALTER TABLE users ADD COLUMN IF NOT EXISTS level INTEGER DEFAULT 1',
      'ALTER TABLE users ADD COLUMN IF NOT EXISTS level_name VARCHAR(100) DEFAULT \'Beginner\'',
      'ALTER TABLE users ADD COLUMN IF NOT EXISTS badges TEXT[] DEFAULT \'{}\'',
      'ALTER TABLE users ADD COLUMN IF NOT EXISTS streak_days INTEGER DEFAULT 0',
      'ALTER TABLE users ADD COLUMN IF NOT EXISTS total_points INTEGER DEFAULT 0'
    ];

    for (const query of alterQueries) {
      try {
        await pool.query(query);
      } catch (error) {
        console.log(`Column might already exist: ${error.message}`);
      }
    }

    res.json({
      message: 'Database tables created successfully',
      tables: ['users']
    });

  } catch (error) {
    console.error('Database initialization error:', error);
    res.status(500).json({ error: 'Database initialization failed', details: error.message });
  }
});

// Admin endpoint to reset user passwords
router.post('/reset-password', async (req, res) => {
  try {
    const { accessCode, email, newPassword } = req.body;
    
    // Check admin access
    if (accessCode !== 'mahtabmehek1337') {
      return res.status(403).json({ error: 'Invalid access code' });
    }

    if (!email || !newPassword) {
      return res.status(400).json({ error: 'Email and new password are required' });
    }

    const pool = req.app.locals.db;
    if (!pool) {
      return res.status(500).json({ error: 'Database connection not available' });
    }

    // Hash the new password
    const saltRounds = 12;
    const newPasswordHash = await bcrypt.hash(newPassword, saltRounds);

    // Update the user's password
    const updateQuery = 'UPDATE users SET password_hash = $1 WHERE email = $2 RETURNING id, email, name, role';
    const result = await pool.query(updateQuery, [newPasswordHash, email]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'Password reset successfully',
      user: result.rows[0],
      newPassword: newPassword
    });

  } catch (error) {
    console.error('Password reset error:', error);
    res.status(500).json({ error: 'Password reset failed', details: error.message });
  }
});

// Admin endpoint to list all users
router.get('/list-users', async (req, res) => {
  try {
    const pool = req.app.locals.db;
    if (!pool) {
      return res.status(500).json({ error: 'Database connection not available' });
    }

    const query = 'SELECT id, email, name, role, is_approved, created_at FROM users ORDER BY id';
    const result = await pool.query(query);

    res.json({
      users: result.rows,
      total: result.rows.length
    });

  } catch (error) {
    console.error('List users error:', error);
    res.status(500).json({ error: 'Failed to list users', details: error.message });
  }
});

module.exports = router;
